import os
from pathlib import Path
from flask import Flask, render_template, send_from_directory, jsonify
from dotenv import load_dotenv
import pandas as pd

from tasks.discover_pdfs import write_games_json
from tasks.scrape import fetch_pdfs
from tasks.parse_pdf import parse_all_pdfs
from tasks.geocode import geocode_missing
from tasks.build_map import build_map

load_dotenv()

app = Flask(__name__)

DATA_DIR = Path("data")
MAPS_DIR = Path("maps")
RAW_DIR = DATA_DIR / "raw"
INPUT_PDF_DIR = Path("data/input_pdfs")
PROCESSED_DIR = DATA_DIR / "processed"
DB_PATH = PROCESSED_DIR / "winners.sqlite"

for p in [MAPS_DIR, RAW_DIR, INPUT_PDF_DIR, PROCESSED_DIR]:
    p.mkdir(parents=True, exist_ok=True)

@app.route("/")
def index():
    map_exists = (MAPS_DIR / "fl_winners_map.html").exists()
    return render_template("index.html", map_exists=map_exists)

@app.route("/map")
def map_view():
    if (MAPS_DIR / "fl_winners_map.html").exists():
        return send_from_directory(MAPS_DIR, "fl_winners_map.html")
    return "No map yet. Click 'Build/Refresh Map' on the homepage.", 404

@app.route("/update")
def update():
    try:
        write_games_json("games.json")  # discover every game PDF we can find today
        fetch_pdfs("games.json", INPUT_PDF_DIR)
        winners_df = parse_all_pdfs(INPUT_PDF_DIR, RAW_DIR, PROCESSED_DIR, DB_PATH)
        winners_df = geocode_missing(winners_df, DB_PATH)
        build_map(winners_df, out_html=MAPS_DIR / "fl_winners_map.html")
        return jsonify({"ok": True, "message": "Map updated", "map_url": "/map"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

if __name__ == "__main__":
    port = int(os.environ.get("FLASK_RUN_PORT", "8000"))
    app.run(host="0.0.0.0", port=port)
