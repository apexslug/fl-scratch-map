# FL Scratch-Off Winner Map — Auto Webapp + CI

Two hosting options:

## A) Static (GitHub Pages) — easiest
- This repo includes a workflow that runs nightly, builds the map, and publishes it to **GitHub Pages**.
- Set repo **Settings → Pages → Build and deployment → GitHub Actions**.
- Add secret(s) for better geocoding:
  - `OPENCAGE_API_KEY` (recommended) and/or `MAPBOX_ACCESS_TOKEN`.

After the first run, your map will be live at:
```
https://<your-username>.github.io/<your-repo>/fl_winners_map.html
```
(the workflow publishes the `maps` folder; the file is `fl_winners_map.html`)

## B) Dynamic (Render / Railway / Fly.io)
- Deploy with the included `Dockerfile`.
- The app runs at `/` with a button to rebuild and `/map` to view the current map.
- Optional: schedule a daily job (e.g., a cron that hits `GET /update`).

## Local Dev
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py   # open http://localhost:8000
```

## How it discovers PDFs
- Scrapes the FL Lottery scratch-off pages for links named **"Winning Ticket Information"** and pulls those PDFs automatically.
- Then it parses, geocodes, and builds the map with color-coded pins by prize:
  - **red**: ≥ $1,000,000
  - **orange**: ≥ $100,000
  - **green**: ≥ $10,000
  - **blue**: otherwise

> Note: Florida’s PDFs mostly list **top-prize winners** with retailer info (not all winners). Formats vary; the parser is heuristic. If one fails, drop a CSV at `data/raw/input_override.csv`.

Enjoy!
