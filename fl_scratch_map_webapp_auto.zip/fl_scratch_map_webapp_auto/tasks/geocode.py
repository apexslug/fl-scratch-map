import os
import time
import requests
import pandas as pd
import sqlite3

def _geocode_opencage(addr, key):
    url = "https://api.opencagedata.com/geocode/v1/json"
    params = {"q": addr, "key": key, "limit": 1}
    r = requests.get(url, params=params, timeout=20)
    r.raise_for_status()
    js = r.json()
    if js.get("results"):
        g = js["results"][0]["geometry"]
        return g.get("lat"), g.get("lng")
    return None, None

def _geocode_mapbox(addr, token):
    url = f"https://api.mapbox.com/geocoding/v5/mapbox.places/{requests.utils.quote(addr)}.json"
    params = {"access_token": token, "limit": 1}
    r = requests.get(url, params=params, timeout=20)
    r.raise_for_status()
    js = r.json()
    if js.get("features"):
        coords = js["features"][0]["geometry"]["coordinates"]
        return coords[1], coords[0]
    return None, None

def _geocode_nominatim(addr):
    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": addr, "format": "json", "limit": 1}
    headers = {"User-Agent": "ScratchMapWeb/1.0 (contact: example@example.com)"}
    r = requests.get(url, params=params, headers=headers, timeout=20)
    r.raise_for_status()
    js = r.json()
    if js:
        return float(js[0]["lat"]), float(js[0]["lon"])
    return None, None

def geocode_missing(df, db_path):
    if "lat" not in df.columns:
        df["lat"] = None
    if "lon" not in df.columns:
        df["lon"] = None

    pref = os.getenv("GEOCODER_PREF", "opencage").lower()
    oc_key = os.getenv("OPENCAGE_API_KEY", "").strip()
    mb_key = os.getenv("MAPBOX_ACCESS_TOKEN", "").strip()

    def geocode(addr):
        if not addr: return (None, None)
        if pref == "opencage" and oc_key:
            try:
                return _geocode_opencage(addr, oc_key)
            except Exception:
                pass
        if pref == "mapbox" and mb_key:
            try:
                return _geocode_mapbox(addr, mb_key)
            except Exception:
                pass
        try:
            time.sleep(1.1)
            return _geocode_nominatim(addr)
        except Exception:
            return (None, None)

    def mk_addr(row):
        parts = []
        for k in ["street","city","state","zip"]:
            v = row.get(k)
            if pd.notna(v) and str(v).strip():
                parts.append(str(v).strip())
        addr = ", ".join(parts)
        if not addr and row.get("address_full"):
            addr = str(row["address_full"])
        return addr

    df["addr_query"] = df.apply(mk_addr, axis=1)

    for idx, row in df[df["lat"].isna()].iterrows():
        addr = row["addr_query"]
        lat, lon = geocode(addr)
        df.at[idx, "lat"] = lat
        df.at[idx, "lon"] = lon

    conn = sqlite3.connect(db_path)
    df.to_sql("winners", conn, if_exists="replace", index=False)
    conn.close()
    return df
