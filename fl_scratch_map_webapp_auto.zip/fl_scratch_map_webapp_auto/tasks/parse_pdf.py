from pathlib import Path
import re
import pdfplumber
import pandas as pd
import sqlite3

CITY_STATE_ZIP_RE = re.compile(r"(.+?),\s*FL\s+(\d{5})(?:-\d{4})?$", re.IGNORECASE)

def parse_pdf(pdf_path: Path, game_id: str, game_name: str):
    rows = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text() or ""
                for line in text.splitlines():
                    if ", FL " in line.upper() and "$" in line:
                        parts = [p.strip() for p in line.replace("—", "-").split("-")]
                        prize = next((p for p in parts if "$" in p), None)
                        date = None
                        for p in parts[::-1]:
                            if re.search(r"\d{4}-\d{2}-\d{2}", p) or re.search(r"\d{1,2}/\d{1,2}/\d{2,4}", p):
                                date = p
                                break
                        retailer_chunk = line.split("$")[0].strip(" -")
                        try:
                            retailer, address = retailer_chunk.rsplit(",", 1)
                            retailer = retailer.strip()
                            address = address.strip()
                        except ValueError:
                            retailer = retailer_chunk
                            address = ""
                        m = CITY_STATE_ZIP_RE.search(line)
                        city = zip_code = None
                        if m:
                            city = m.group(1).split(",")[-1].strip()
                            zip_code = m.group(2)
                        rows.append({
                            "game_id": game_id,
                            "game_name": game_name,
                            "retailer": retailer,
                            "address_full": retailer_chunk,
                            "street": address,
                            "city": city,
                            "state": "FL",
                            "zip": zip_code,
                            "prize": prize,
                            "claim_date": date
                        })
    except Exception as e:
        print(f"⚠️ PDF parse failed for {pdf_path.name}: {e}")
    return rows

def parse_all_pdfs(input_pdf_dir: Path, raw_dir: Path, processed_dir: Path, db_path: Path):
    processed_dir.mkdir(parents=True, exist_ok=True)
    all_rows = []

    override_csv = raw_dir / "input_override.csv"
    if override_csv.exists():
        df_override = pd.read_csv(override_csv)
    else:
        df_override = pd.DataFrame(columns=[
            "game_id","game_name","retailer","street","city","state","zip","prize","claim_date"
        ])

    for pdf in input_pdf_dir.glob("*.pdf"):
        game_id = pdf.stem
        game_name = game_id
        rows = parse_pdf(pdf, game_id, game_name)
        all_rows.extend(rows)

    df_pdf = pd.DataFrame(all_rows)
    df = pd.concat([df_pdf, df_override], ignore_index=True, axis=0)
    df.drop_duplicates(subset=["game_id","retailer","address_full","prize"], inplace=True)
    if "prize" in df.columns:
        df["prize_amount"] = pd.to_numeric(
            df["prize"].str.replace(r"[^0-9.]", "", regex=True), errors="coerce"
        )

    out_csv = processed_dir / "winners.csv"
    df.to_csv(out_csv, index=False)

    conn = sqlite3.connect(db_path)
    df.to_sql("winners", conn, if_exists="replace", index=False)
    conn.close()
    return df
