import folium
from folium.plugins import MarkerCluster
from pathlib import Path

def _format_popup(row):
    prize = row.get("prize") or ""
    date = row.get("claim_date") or ""
    game = row.get("game_name") or row.get("game_id") or ""
    retailer = row.get("retailer") or ""
    addr = row.get("addr_query") or ""
    html = (
        f"<b>{retailer}</b><br/>"
        f"{addr}<br/>"
        f"<b>Game:</b> {game}<br/>"
        f"<b>Prize:</b> {prize}<br/>"
        f"<b>Claimed:</b> {date}"
    )
    return html

def build_map(df, out_html: Path):
    df_map = df.dropna(subset=["lat","lon"]).copy()
    if df_map.empty:
        m = folium.Map(location=[27.6648, -81.5158], zoom_start=6)
        m.save(out_html)
        return

    center_lat = df_map["lat"].median()
    center_lon = df_map["lon"].median()
    m = folium.Map(location=[center_lat, center_lon], zoom_start=6)

    cluster = MarkerCluster().add_to(m)

    def color_for_prize(val):
        try:
            amount = float(str(val).replace(",", "").replace("$",""))
        except Exception:
            amount = 0.0
        if amount >= 1_000_000:
            return "red"
        if amount >= 100_000:
            return "orange"
        if amount >= 10_000:
            return "green"
        return "blue"

    for _, row in df_map.iterrows():
        popup_html = _format_popup(row)
        folium.CircleMarker(
            location=[row["lat"], row["lon"]],
            radius=6,
            color=color_for_prize(row.get("prize")),
            fill=True,
            fill_opacity=0.8,
            popup=folium.Popup(popup_html, max_width=300)
        ).add_to(cluster)

    m.save(out_html)
