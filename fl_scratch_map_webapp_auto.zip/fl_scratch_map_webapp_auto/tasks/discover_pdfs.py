import re, json
from pathlib import Path
from bs4 import BeautifulSoup
import requests

BASE = "https://floridalottery.com"
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; ScratchMapWeb/1.1)"}

def _get(url):
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    return r.text

def discover_all_games():
    # Hit scratch-offs landing, then follow "Top Prizes Remaining" for list of game IDs/names
    # Fallback: scrape /games/scratch-offs and follow each "View Scratch-Off" link
    games = {}
    # 1) Top remaining prizes page (has table with game ids and links)
    try:
        html = _get(f"{BASE}/games/scratch-offs/top-remaining-prizes")
        soup = BeautifulSoup(html, "html.parser")
        for a in soup.select("a[href*='games/scratch-offs/view?id=']"):
            href = a.get("href")
            gid = re.search(r"id=(\d+)", href)
            if gid:
                games[gid.group(1)] = {"game_id": gid.group(1), "game_name": a.get_text(strip=True)}
    except Exception:
        pass

    # 2) Scratch-offs index (catch any missed games)
    try:
        html = _get(f"{BASE}/games/scratch-offs")
        soup = BeautifulSoup(html, "html.parser")
        for a in soup.select("a[href*='games/scratch-offs/view?id=']"):
            href = a.get("href")
            gid = re.search(r"id=(\d+)", href)
            if gid:
                games.setdefault(gid.group(1), {"game_id": gid.group(1), "game_name": a.get_text(strip=True)})
    except Exception:
        pass

    # For each game page, try to find "Winning Ticket Information" PDF
    results = []
    for gid, meta in games.items():
        try:
            page_html = _get(f"{BASE}/games/scratch-offs/view?id={gid}")
            s = BeautifulSoup(page_html, "html.parser")
            pdf_url = None
            # Look for links ending in _WinningTicketInformation.pdf or containing 'Winning Ticket Information'
            for a in s.find_all("a", href=True):
                href = a['href']
                text = a.get_text(" ", strip=True).lower()
                if "winning ticket information" in text or href.endswith("WinningTicketInformation.pdf") or "WinningTicketInformation" in href:
                    if href.startswith("http"):
                        pdf_url = href
                    else:
                        # Many are at files.floridalottery.com/exptkt/...
                        if href.startswith("//"):
                            pdf_url = "https:" + href
                        else:
                            pdf_url = BASE + href if href.startswith("/") else f"{BASE}/{href}"
                    break
            if pdf_url:
                name = meta.get("game_name") or gid
                results.append({"game_id": gid, "game_name": name, "pdf_url": pdf_url})
        except Exception:
            continue

    # Deduplicate
    seen = set()
    deduped = []
    for g in results:
        key = (g["game_id"], g["pdf_url"])
        if key not in seen:
            seen.add(key)
            deduped.append(g)
    return deduped

def write_games_json(path="games.json"):
    games = discover_all_games()
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"games": games}, f, indent=2)
    return games

if __name__ == "__main__":
    out = write_games_json()
    print(f"Discovered {len(out)} games with PDFs")
