import json
from pathlib import Path
import requests
from tqdm import tqdm

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; ScratchMapWeb/1.0)"}

def fetch_pdfs(config_path, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(Path(config_path).read_text())
    for game in cfg.get("games", []):
        url = game["pdf_url"]
        game_id = game["game_id"]
        fname = out_dir / f"{game_id}.pdf"
        print(f"Downloading {game_id} from {url} ...")
        try:
            with requests.get(url, headers=HEADERS, stream=True, timeout=30) as r:
                r.raise_for_status()
                total = int(r.headers.get("content-length", 0))
                with open(fname, "wb") as f, tqdm(total=total, unit="B", unit_scale=True) as bar:
                    for chunk in r.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            bar.update(len(chunk))
        except Exception as e:
            print(f"  ⚠️ Failed to fetch {url}: {e}")
